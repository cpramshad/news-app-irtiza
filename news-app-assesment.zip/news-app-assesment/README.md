# News app assessment

### [Live preview](https://newsapp-assesment.netlify.app/)

### Built with
The app is built with [Vitejs](https://vitejs.dev/) with it's SWC typescript compiler and I used **yarn** as the package manager.

### Setup
First clone the repository
```
git clone https://github.com/Irtiza751/news-app-assesment.git
```
**NOTE:** don't forget to add the `api key` in the .env file; you will also find the `.env.sample` just file copy that & change it's value(s).

Then cd in to the `cd news-app-assesment` & run `yarn install` once all dependencies are installed; run
```
yarn dev
```
The app will start on the bellow URL.
```
http://localhost:5173/
```
#### Screenshot [Live preview](https://newsapp-assesment.netlify.app/)
![Screenshot from 2023-10-14 13-25-10](https://github.com/Irtiza751/news-app-assesment/assets/91867702/4490df56-df32-4772-b160-e1a5f736e9b2)
