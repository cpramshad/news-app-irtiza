### TODO

- [ ] pagination
- [x] query dropdown options
- [x] Change language en/ar
- [x] show loading while fetching data
