import { Box, Grid, Skeleton } from "@mui/material";

const mockItems = new Array(7).fill(1);

export default function NewsSkeleton() {
  return (
    <Box my={2}>
      <Grid container spacing={2}>
        {mockItems.map((_, i) => (
          <Grid key={i} item xs={i === 0 ? 12 : 4}>
            <Skeleton
              variant="rectangular"
              height={i === 0 ? "300px" : "500px"}
            />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
