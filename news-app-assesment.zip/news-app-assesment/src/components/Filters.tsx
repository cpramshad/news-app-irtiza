import { Box, Grid, SelectChangeEvent } from "@mui/material";
import SelectInput from "../shared/SelectInput";
import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { fetchNews } from "../redux/actions/fetchNews";
import { AppDispatch } from "../redux/store";
import { useNewsParams } from "../hooks/useNewsParams";

// apple / meta / netflix / google / twitter / tesla
interface Option {
  name: string;
  value: string;
}

const options: Option[] = [
  { name: "Apple", value: "apple" },
  { name: "Meta", value: "meta" },
  { name: "Netflix", value: "netflix" },
  { name: "Google", value: "google" },
  { name: "Twitter", value: "twitter" },
  { name: "Tesla", value: "tesla" },
];

export function Filters() {
  const dispatch = useDispatch<AppDispatch>();
  const [query, setQuery] = useState("apple");
  const [pageSize, setPageSize] = useState("10");
  const { paramsObj, changeParams } = useNewsParams();
  const initialMount = useRef(true);

  const handleQuerySelect = (e: SelectChangeEvent) => {
    setQuery(e.target.value);
    changeParams({
      type: "UPDATE",
      payload: { query: e.target.value },
    });
  };

  const handlePageSelect = (e: SelectChangeEvent) => {
    setPageSize(e.target.value);
    changeParams({
      type: "UPDATE",
      payload: { pageSize: Number(e.target.value) },
    });
  };

  useEffect(() => {
    if (initialMount.current) {
      initialMount.current = false;
    } else {
      dispatch(fetchNews(paramsObj));
    }
  }, [paramsObj, dispatch]);

  return (
    <Box sx={{ borderBottom: "1px solid #8080802b" }} pb={2}>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <SelectInput
            label="Query"
            options={options}
            value={query}
            onSelect={handleQuerySelect}
          />
        </Grid>
        <Grid item xs={6}>
          <SelectInput
            label="Page size"
            options={[
              { name: "10", value: "10" },
              { name: "20", value: "20" },
              { name: "30", value: "30" },
            ]}
            value={pageSize}
            onSelect={handlePageSelect}
          />
        </Grid>
      </Grid>
    </Box>
  );
}
