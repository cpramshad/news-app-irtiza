import {
  Button,
  Card,
  CardContent,
  CardMedia,
  Typography,
} from "@mui/material";
import { Article } from "../types/newsInterface";

interface NewsProps {
  item: Article;
  isFirstItem: boolean;
}

export function News({ item, isFirstItem }: NewsProps) {
  return (
    <Card sx={{ display: isFirstItem ? "flex" : "inherit" }}>
      <CardMedia
        sx={
          isFirstItem ? { maxWidth: "700px", width: "100%" } : { height: 200 }
        }
        image={item.urlToImage}
        title={item.title}
        component="div"
      />
      <CardContent>
        <Typography color="blue" variant="caption">
          {new Date(item.publishedAt).toDateString()}
        </Typography>
        <Typography variant="h5" mb={2}>
          {item.title}
        </Typography>
        <Typography mb={2}>{item.description}</Typography>
        <Button fullWidth variant="outlined" href={item.url} target="_blank">
          Read more
        </Button>
      </CardContent>
    </Card>
  );
}
