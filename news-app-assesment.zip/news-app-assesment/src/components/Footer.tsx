import { Box, Typography } from "@mui/material";

export function Footer() {
  return (
    <Box
      component="footer"
      py={2}
      mt={3}
      sx={{
        borderTop: "1px solid #8080802b",
      }}
    >
      <Typography textAlign="center">Copyright 2023</Typography>
    </Box>
  );
}
