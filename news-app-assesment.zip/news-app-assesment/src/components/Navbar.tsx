import {
  AppBar,
  Box,
  Button,
  Container,
  IconButton,
  Toolbar,
  Typography,
} from "@mui/material";
import { Brightness4, BrightnessHigh, Newspaper } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../redux/store";
import { changeDirection, toggleTheme } from "../redux/slices/themeSlice";
import { useLayoutEffect } from "react";

export default function Navbar() {
  const { isDark, direction } = useSelector((state: RootState) => state.theme);
  const dispatch = useDispatch<AppDispatch>();

  useLayoutEffect(() => {
    document.dir = direction;
  }, [direction]);

  return (
    <Box sx={{ flexGrow: 1 }} mb={14}>
      <AppBar position="fixed" component="nav">
        <Container sx={{ py: 1 }}>
          <Toolbar variant="dense">
            <Box
              sx={{
                flexGrow: 1,
                display: "flex",
                alignItems: "center",
                gap: 1,
              }}
            >
              <Newspaper />
              <Typography
                variant="h6"
                color="inherit"
                component="div"
                fontSize={22}
              >
                News App
              </Typography>
            </Box>

            <Button
              color="inherit"
              variant="outlined"
              onClick={() => {
                const dir = direction == "ltr" ? "rtl" : "ltr";
                dispatch(changeDirection(dir));
              }}
            >
              En/Ar
            </Button>

            <IconButton color="inherit" onClick={() => dispatch(toggleTheme())}>
              {isDark ? <BrightnessHigh /> : <Brightness4 />}
            </IconButton>
          </Toolbar>
        </Container>
      </AppBar>
    </Box>
  );
}
