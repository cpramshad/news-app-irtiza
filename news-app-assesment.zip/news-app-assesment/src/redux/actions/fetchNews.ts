import { createAsyncThunk } from "@reduxjs/toolkit";
import { news } from "../../api/news";
import { News } from "../../types/newsInterface";
import { getDateOfPast7thDay } from "../../utils/getDateOfPast7thDay";
import { AxiosError } from "axios";
import { BackendParmas } from "../../types/ParamsInterface";

export const fetchNews = createAsyncThunk(
  "news/fetch",
  async (params: Partial<BackendParmas> | undefined, { rejectWithValue }) => {
    try {
      const { data } = await news.get<News>("", {
        params: {
          q: params?.query || "apple",
          pageSize: params?.pageSize || 10,
          sortBy: "publishedAt",
          from: getDateOfPast7thDay(),
          language: params?.lang || "en",
          page: params?.page || 1,
        },
      });

      return data;
    } catch (error) {
      if (error instanceof AxiosError) {
        return rejectWithValue(error.response?.data);
      }
    }
  }
);
