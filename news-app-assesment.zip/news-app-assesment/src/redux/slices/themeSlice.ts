import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type Direction = "ltr" | "rtl";

export interface ThemeState {
  isDark: boolean;
  direction: Direction;
}

const initialState: ThemeState = {
  isDark: false,
  direction: "ltr",
};

export const themeSlice = createSlice({
  name: "theme",
  initialState,

  reducers: {
    toggleTheme(state) {
      state.isDark = !state.isDark;
    },

    changeDirection(state, { payload }: PayloadAction<Direction>) {
      state.direction = payload;
    },
  },
});

export const { toggleTheme, changeDirection } = themeSlice.actions;

export default themeSlice.reducer;
