import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { Article } from "../../types/newsInterface";
import { fetchNews } from "../actions/fetchNews";
// dummy data
// import data from "../../assets/data/dummy.json";

export interface NewsState {
  news: Article[] | null;
  loading: boolean;
  errorMsg: string | null;
}

const initialState: NewsState = {
  news: null,
  loading: false,
  errorMsg: null,
};

export const newsSlice = createSlice({
  name: "news",
  initialState,

  reducers: {
    getNews(state, payload: PayloadAction) {
      console.log(state, payload);
    },

    clearError(state) {
      state.errorMsg = null;
    },
  },

  extraReducers: (builder) => {
    // for lading state
    builder.addCase(fetchNews.pending, (state) => {
      state.loading = true;
    });

    // for success state
    builder.addCase(fetchNews.fulfilled, (state, { payload }) => {
      state.loading = false;
      if (payload?.articles) {
        state.news = payload.articles;
      }
    });

    // for failed state
    builder.addCase(fetchNews.rejected, (state, { payload }) => {
      state.loading = false;
      const error = payload as { message: string };
      if (error?.message) {
        state.errorMsg = error.message;
      }
    });
  },
});

export const { getNews, clearError } = newsSlice.actions;

export default newsSlice.reducer;
