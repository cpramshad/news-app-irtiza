export const getDateOfPast7thDay = () => {
  const currentDate = new Date();
  // Calculating the day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
  const currentDayOfWeek = currentDate.getDay();
  // Calculate the date of the past 7th day
  const past7thDayDate = new Date(currentDate);
  past7thDayDate.setDate(currentDate.getDate() - (currentDayOfWeek + 7));
  return past7thDayDate.toISOString();
};
