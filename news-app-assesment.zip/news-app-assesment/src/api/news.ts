import axios from "axios";

// loading env variables
const API_KEY = import.meta.env.VITE_NEWS_API_KEY;

// https://newsapi.org/v2/everything?q=Apple&from=2023-10-10&sortBy=popularity&apiKey=API_KEY
export const news = axios.create({
  baseURL: `https://newsapi.org/v2/everything`,
});

// intercepting each request and adding the apiKey.
news.interceptors.request.use(function (config) {
  config.params.apiKey = API_KEY;
  return config;
});
