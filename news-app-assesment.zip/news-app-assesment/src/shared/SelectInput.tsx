import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";

interface SelectInputProps {
  label: string;
  options: { name: string; value: string }[];
  onSelect: (event: SelectChangeEvent) => void;
  value: string;
}

export default function SelectInput({
  label,
  options,
  value,
  onSelect,
}: SelectInputProps) {
  return (
    <Box>
      <FormControl fullWidth>
        <InputLabel>{label}</InputLabel>
        <Select value={value} label={label} onChange={onSelect}>
          {options.map((option, i) => (
            <MenuItem key={i} value={option.value}>
              {option.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
}
