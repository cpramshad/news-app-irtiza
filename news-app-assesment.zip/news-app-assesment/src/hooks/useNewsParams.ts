import { useEffect, useReducer } from "react";
import { BackendParmas } from "../types/ParamsInterface";

interface ReturnData {
  paramsObj: BackendParmas;
  changeParams: React.Dispatch<Action>;
}

interface Action {
  type: "UPDATE" | "RESET";
  payload: Partial<BackendParmas>;
}

const reducer = (state: BackendParmas, action: Action) => {
  switch (action.type) {
    case "UPDATE":
      console.log(action.payload);
      return { ...state, ...action.payload };
    case "RESET":
      return initialState;
    default:
      return state;
  }
};

const initialState: BackendParmas = {
  query: "apple",
  pageSize: 10,
  lang: "en",
  page: 1,
};

export function useNewsParams(): ReturnData {
  const [paramsObj, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    console.log("parms: ", paramsObj);
  }, [paramsObj]);

  return {
    paramsObj,
    changeParams: dispatch,
  };
}
