import {
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Grid,
  IconButton,
  Modal,
  Typography,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import WarningAmberRoundedIcon from "@mui/icons-material/WarningAmberRounded";
import { AppDispatch, RootState } from "../redux/store";
import { News } from "../components/News";
import { fetchNews } from "../redux/actions/fetchNews";
import { useEffect, useRef } from "react";
import { Filters } from "../components/Filters";
import { clearError } from "../redux/slices/newsSlice";
import { Close as CloseIcon } from "@mui/icons-material";
import { useNewsParams } from "../hooks/useNewsParams";

const modalStyle = {
  maxWidth: 600,
  margin: "auto",
  marginTop: "10%",
  outline: "none",
};

/*
 * declearing the page number outside form component
 * to prevent it from resetting
 */
let pageNo = 1;

export function Home() {
  const { news, errorMsg } = useSelector((state: RootState) => state.news);
  const { direction } = useSelector((state: RootState) => state.theme);
  const dispatch = useDispatch<AppDispatch>();
  const initialMount = useRef(true);
  const { paramsObj, changeParams } = useNewsParams();

  useEffect(() => {
    if (initialMount.current) {
      // only call the api on 1st render.
      dispatch(fetchNews(paramsObj));
    } else {
      initialMount.current = false;
    }
  }, [paramsObj, dispatch]);

  useEffect(() => {
    if (initialMount.current) {
      initialMount.current = false;
    } else {
      // call the api every time parmsObj change except 1st time.
      dispatch(fetchNews(paramsObj));
    }
  }, [paramsObj, dispatch]);

  useEffect(() => {
    changeParams({
      type: "UPDATE",
      payload: { lang: direction === "ltr" ? "en" : "ar" },
    });
  }, [direction, changeParams]);

  const loadmoreNews = () => {
    changeParams({
      type: "UPDATE",
      payload: {
        page: pageNo++,
      },
    });
  };

  return (
    <>
      <Box mb={2}>
        <Filters />
      </Box>
      <Modal open={errorMsg !== null} onClose={() => dispatch(clearError())}>
        <Card sx={modalStyle}>
          <CardHeader
            sx={{ borderBottom: "1px solid #8080802b" }}
            title="Error Message"
            action={
              <IconButton onClick={() => dispatch(clearError())}>
                <CloseIcon />
              </IconButton>
            }
          />
          <CardContent sx={{ textAlign: "center" }}>
            <WarningAmberRoundedIcon color="error" sx={{ fontSize: 50 }} />
            <Typography fontSize={18} textAlign="center">
              {errorMsg}
            </Typography>
          </CardContent>
        </Card>
      </Modal>
      <Grid container spacing={2}>
        {news
          ? news.map((item, i) => (
              <Grid key={i} item xs={i === 0 ? 12 : 4}>
                <News item={item} isFirstItem={i === 0} />
              </Grid>
            ))
          : null}
      </Grid>
      <Box mt="5" display="flex" justifyContent="center">
        <Button
          onClick={loadmoreNews}
          variant="contained"
          size="large"
          disableElevation
        >
          Load more
        </Button>
      </Box>
    </>
  );
}
