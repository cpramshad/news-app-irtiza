import {
  Container,
  CssBaseline,
  ThemeProvider,
  createTheme,
} from "@mui/material";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState } from "./redux/store";

function App() {
  const { isDark } = useSelector((state: RootState) => state.theme);

  const theme = useMemo(() => {
    return createTheme({
      palette: {
        mode: isDark ? "dark" : "light",
      },
    });
  }, [isDark]);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Layout>
        <Container>
          <Home />
        </Container>
      </Layout>
    </ThemeProvider>
  );
}

export default App;
