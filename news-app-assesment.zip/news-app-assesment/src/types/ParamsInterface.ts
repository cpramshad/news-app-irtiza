export interface BackendParmas {
  query: string;
  pageSize: number;
  lang: "en" | "ar";
  page: number;
}
